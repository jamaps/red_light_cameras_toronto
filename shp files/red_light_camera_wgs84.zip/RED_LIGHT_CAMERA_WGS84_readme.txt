RED_LIGHT_CAMERA_WGS84_readme
 

Column name  (Description)
======================================
ROAD_1 = LINEAR_NAME_FULL_1  (First road of Intersection)
ROAD_2 = LINEAR_NAME_FULL_2  (Second road of Intersection)
X = X  (Easting in MTM NAD27 3 degree Projection)
Y = Y  (Northing in MTM NAD27 3 degree Projection)
LONGITUDE = LONGITUDE  (Longitude in WGS84 Coordinate System)
LATITUDE = LATITUDE  (Latitude in WGS84 Coordinate System)
OBJECTID = OBJECTID  (Unique system identifier)
